#include "CubeRenderObject.h"

CubeRenderObject::CubeRenderObject(RenderProxy* pRenderProxy) :
	RenderObject(pRenderProxy)
{
	
}

CubeRenderObject1::CubeRenderObject1(RenderProxy* pRenderProxy) :
	RenderObject(pRenderProxy)
{

}