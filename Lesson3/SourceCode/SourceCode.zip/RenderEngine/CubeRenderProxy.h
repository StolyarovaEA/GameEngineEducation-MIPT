#pragma once

#include "RenderProxy.h"

class CubeRenderProxy final : public RenderProxy
{
public:
	CubeRenderProxy() = default;
};

