#include "CubeRenderObject.h"

CubeRenderObject::CubeRenderObject(RenderProxy* pRenderProxy) :
	RenderObject(pRenderProxy)
{
	
}