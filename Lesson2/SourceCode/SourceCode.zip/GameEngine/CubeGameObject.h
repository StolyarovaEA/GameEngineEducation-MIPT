#pragma once

#include "GameObject.h"

class CubeGameObject final : public GameObject
{
public:
	CubeGameObject();

private:
	
};

