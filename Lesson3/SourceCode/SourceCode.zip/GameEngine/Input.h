#pragma once

enum EInputCommand : size_t
{
	eIC_GoLeft = 0,
	eIC_GoRight,

	eIC_Max
};
