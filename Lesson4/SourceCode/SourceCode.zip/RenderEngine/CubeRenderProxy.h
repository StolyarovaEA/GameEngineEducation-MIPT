#pragma once

#include "RenderProxy.h"

class CubeRenderProxy final : public RenderProxy
{
public:
	CubeRenderProxy() = default;
};

class CubeRenderProxy1 final : public RenderProxy
{
public:
	CubeRenderProxy1() = default;
};
